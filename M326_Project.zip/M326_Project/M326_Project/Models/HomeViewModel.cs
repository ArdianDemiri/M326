﻿using System;
using System.Collections.Generic;
using M326_Project.Data;

namespace M326_Project.Models
{
    public class HomeViewModel
    {
        public List<Job> Jobs { get; set; }
    }
}
