﻿using System;
namespace M326_Project.Models
{
    public class HardwareReqRecViewModel
    {
        public int ID_rec { get; set; }
        public int Job_ID { get; set; }
        public int processor_core_count_rec { get; set; }
        public int processor_frequency_mhz_rec { get; set; }
        public int memory_mb_rec { get; set; }
        public int storage_capacity_mb_rec { get; set; }
        public string storage_type_rec { get; set; }
        public double display_size_inch_rec { get; set; }
        public Boolean usb_c_rec { get; set; }
        public Boolean touchscreen_rec { get; set; }
        public Boolean pen_rec { get; set; }
        public string specs_type_rec { get; set; }

        public int ID_req { get; set; }
        public int processor_core_count_req { get; set; }
        public int processor_frequency_mhz_req { get; set; }
        public int memory_mb_req { get; set; }
        public int storage_capacity_mb_req { get; set; }
        public string storage_type_req { get; set; }
        public double display_size_inch_req { get; set; }
        public Boolean usb_c_req { get; set; }
        public Boolean touchscreen_req { get; set; }
        public Boolean pen_req { get; set; }
        public string specs_type_req { get; set; }
    }
}
