﻿using System;
namespace M326_Project.Models
{
    public class HardwareViewModel
    {
        public int Job_ID { get; set; }
        public int processor_core_count { get; set; }
        public int processor_frequency_mhz { get; set; }
        public int memory_mb { get; set; }
        public int storage_capacity_mb { get; set; }
        public string storage_type { get; set; }
        public double display_size_inch { get; set; }
        public Boolean usb_c { get; set; }
        public Boolean touchscreen { get; set; }
        public Boolean pen { get; set; }
    }
}
