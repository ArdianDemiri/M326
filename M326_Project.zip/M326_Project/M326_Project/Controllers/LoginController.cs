﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using M326_Project.Models;
using M326_Project.Data;
using MySqlX.XDevAPI;
using Renci.SshNet;

namespace M326_Project.Controllers
{
    public class LoginController : Controller
    {
        public static bool isLoggedIn { get; set; }
        private readonly ILogger<LoginController> _logger;
        private readonly MyDbContext _context;

        public LoginController(ILogger<LoginController> logger, MyDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        // Required to be logged in
        public IActionResult Index()
        {
            //Session["isLockedIn"] = true;
            if(isLoggedIn == true)
            {
                var jobs = _context.Job.ToList();
                return View(jobs);
            } else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Login()
        {
            return View();
        }

        // Required to be logged in
        public IActionResult LoginPOST(string inputUsername, string inputPassword)
        {
            Account account = new Account();
            var hashedPass = account.ToSHA256(inputPassword);
            account.Password = hashedPass;
            account.Username = inputUsername;
            var login = _context.Account.
            Where(n => n.Username == account.Username
            && n.Password == account.Password).Count();

            if (login != 0)
            {
                isLoggedIn = true;
                return RedirectToAction("Index");
            }
            else
            {
                // Fehlermeldung bzw. nicht korrektes Login
                return RedirectToAction("Login");
            }
        }

        // Required to be logged in
        public IActionResult Create(string jobName)
        {
            if (isLoggedIn == true)
            {
                Job job = new Job();
                job.JobName = jobName;
                _context.Job.Add(job);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Required to be logged in
        public IActionResult Delete(int ID)
        {
            if (isLoggedIn == true)
            {
                var job = _context.Job.Where(n => n.ID == ID).FirstOrDefault();
                _context.Job.Remove(job);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Required to be logged in
        public IActionResult Hardware(int ID)
        {
            if (isLoggedIn == true)
            {
                HardwareReqRecViewModel hardwareView = new HardwareReqRecViewModel();
                var hardware = _context.Hardware.Where(n => n.Job_ID == ID && n.specs_type == "REC").FirstOrDefault();
                if (hardware == null)
                {
                    hardwareView.Job_ID = ID;

                    // Recommended
                    hardwareView.memory_mb_rec = 0;
                    hardwareView.processor_core_count_rec = 0;
                    hardwareView.processor_frequency_mhz_rec = 0;
                    hardwareView.storage_capacity_mb_rec = 0;
                    hardwareView.storage_type_rec = "HDD";
                    hardwareView.usb_c_rec = false;
                    hardwareView.touchscreen_rec = false;
                    hardwareView.pen_rec = false;
                    hardwareView.specs_type_rec = "REC";

                    // Required
                    hardwareView.memory_mb_req = 0;
                    hardwareView.processor_core_count_req = 0;
                    hardwareView.processor_frequency_mhz_req = 0;
                    hardwareView.storage_capacity_mb_req = 0;
                    hardwareView.storage_type_req = "HDD";
                    hardwareView.usb_c_req = false;
                    hardwareView.touchscreen_req = false;
                    hardwareView.pen_req = false;
                    hardwareView.specs_type_req = "REQ";

                    // Speichern von Recommended
                    hardware = new Hardware();
                    hardware.Job_ID = ID;
                    hardware.processor_core_count = hardwareView.processor_core_count_rec;
                    hardware.processor_frequency_mhz = hardwareView.processor_frequency_mhz_rec;
                    hardware.storage_capacity_mb = hardwareView.storage_capacity_mb_rec;
                    hardware.storage_type = hardwareView.storage_type_rec;
                    hardware.usb_c = hardwareView.usb_c_rec;
                    hardware.touchscreen = hardwareView.touchscreen_rec;
                    hardware.pen = hardwareView.pen_rec;
                    hardware.specs_type = hardwareView.specs_type_rec;

                    List<Hardware> hardwares = new List<Hardware>();
                    hardwares.Add(hardware);
                    Hardware item2 = new Hardware();

                    item2.Job_ID = 0;
                    item2.processor_core_count = 0;
                    item2.processor_frequency_mhz = 0;
                    item2.storage_capacity_mb = 0;
                    item2.storage_type = "HDD";
                    item2.usb_c = false;
                    item2.touchscreen = false;
                    item2.pen = false;
                    item2.specs_type = "REQ";
                    item2.Job_ID = ID;

                    hardwares.Add(item2);

                    foreach (Hardware item in hardwares)
                    {
                        _context.Hardware.Add(item);
                        _context.SaveChanges();
                    }

                    var ID_REC = _context.Hardware.Where(n => n.Job_ID == ID && n.specs_type == "REC").FirstOrDefault().ID;
                    var ID_REQ = _context.Hardware.Where(n => n.Job_ID == ID && n.specs_type == "REQ").FirstOrDefault().ID;

                    hardwareView.Job_ID = ID;
                    hardwareView.ID_rec = ID_REC;
                    hardwareView.ID_req = ID_REQ;
                } else
                {
                    // Recommended
                    hardwareView.ID_rec = hardware.ID;
                    hardwareView.memory_mb_rec = hardware.memory_mb;
                    hardwareView.processor_core_count_rec = hardware.processor_core_count;
                    hardwareView.processor_frequency_mhz_rec = hardware.processor_frequency_mhz;
                    hardwareView.storage_capacity_mb_rec = hardware.storage_capacity_mb;
                    hardwareView.storage_type_rec = hardware.storage_type;
                    hardwareView.usb_c_rec = hardware.usb_c;
                    hardwareView.touchscreen_rec = hardware.touchscreen;
                    hardwareView.pen_rec = hardware.pen;
                    hardwareView.specs_type_rec = hardware.specs_type;
                    hardwareView.display_size_inch_rec = hardware.display_size_inch;

                    hardware = _context.Hardware.Where(n => n.Job_ID == ID && n.specs_type == "REQ").FirstOrDefault();

                    // Required
                    hardwareView.ID_req = hardware.ID;
                    hardwareView.memory_mb_req = hardware.memory_mb;
                    hardwareView.processor_core_count_req = hardware.processor_core_count;
                    hardwareView.processor_frequency_mhz_req = hardware.processor_frequency_mhz;
                    hardwareView.storage_capacity_mb_req = hardware.storage_capacity_mb;
                    hardwareView.storage_type_req = hardware.storage_type;
                    hardwareView.usb_c_req = hardware.usb_c;
                    hardwareView.touchscreen_req = hardware.touchscreen;
                    hardwareView.pen_req = hardware.pen;
                    hardwareView.specs_type_rec = hardware.specs_type;
                    hardwareView.display_size_inch_req = hardware.display_size_inch;

                    hardwareView.Job_ID = ID;
                }
                return View(hardwareView);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Required to be logged in
        public IActionResult HardwarePOST(int ID_rec, int Job_ID, int core_count_rec, int core_mhz_rec, int memory_mb_rec,
        int storage_mb_rec, string storage_type_rec, double display_size_rec, bool usb_c_rec, bool touch_rec, bool pen_rec,
        int core_count_req, int core_mhz_req, int memory_mb_req,
        int storage_mb_req, string storage_type_req, double display_size_req, bool usb_c_req, bool touch_req, bool pen_req, int ID_req)
        {
            if (isLoggedIn == true)
            {
                var hardware_rec = new Hardware();
                hardware_rec.ID = ID_rec;
                hardware_rec.Job_ID = Job_ID;
                hardware_rec.processor_core_count = core_count_rec;
                hardware_rec.processor_frequency_mhz = core_mhz_rec;
                hardware_rec.memory_mb = memory_mb_rec;
                hardware_rec.storage_capacity_mb = storage_mb_rec;
                hardware_rec.storage_type = storage_type_rec;
                hardware_rec.display_size_inch = display_size_rec;
                hardware_rec.usb_c = usb_c_rec;
                hardware_rec.touchscreen = touch_rec;
                hardware_rec.pen = pen_rec;
                hardware_rec.specs_type = "REC";

                var hardware_req = new Hardware();
                hardware_req.ID = ID_req;
                hardware_req.Job_ID = Job_ID;
                hardware_req.processor_core_count = core_count_req;
                hardware_req.processor_frequency_mhz = core_mhz_req;
                hardware_req.memory_mb = memory_mb_req;
                hardware_req.storage_capacity_mb = storage_mb_req;
                hardware_req.storage_type = storage_type_req;
                hardware_req.display_size_inch = display_size_req;
                hardware_req.usb_c = usb_c_req;
                hardware_req.touchscreen = touch_req;
                hardware_req.pen = pen_req;
                hardware_req.specs_type = "REQ";

                List<Hardware> hardwares = new List<Hardware>();
                hardwares.Add(hardware_rec);
                hardwares.Add(hardware_req);

                foreach(Hardware item in hardwares)
                {
                    _context.Hardware.Update(item);
                    _context.SaveChanges();
                }

                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Required to be logged in
        public IActionResult Back(int ID)
        {
            if (isLoggedIn == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Required to be logged in
        public IActionResult Edit(int ID)
        {
            if (isLoggedIn == true)
            {
                var job = _context.Job.Where(n => n.ID == ID).FirstOrDefault();
                return View(job);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        // Required to be logged in
        public IActionResult EditPOST(int ID, string jobName)
        {
            if (isLoggedIn == true)
            {
                var job = _context.Job.Where(n => n.ID == ID).FirstOrDefault();
                job.JobName = jobName;
                _context.Job.Update(job);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Logout()
        {
            isLoggedIn = false;
            return RedirectToAction("Index", "Home");
        }
    }
}
