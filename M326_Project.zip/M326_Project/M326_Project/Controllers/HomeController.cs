﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using M326_Project.Models;
using M326_Project.Data;

namespace M326_Project.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MyDbContext _context;

        public HomeController(ILogger<HomeController> logger, MyDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            var job = _context.Job.ToList();
            return View(job);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Chart(int Job_ID, int processor_core, int processor_mhz, int memory_mb,
            int storage_mb, int display_size, string storage_type, Boolean usb_c, Boolean touchscreen, Boolean pen)
        {
            ChartViewModel chart = new ChartViewModel();

            var hardware = _context.Hardware.Where(n => n.Job_ID == Job_ID && n.specs_type == "REQ").FirstOrDefault();
            if (hardware != null)
            {
                chart.display_size_inch_req = hardware.display_size_inch;
                chart.memory_mb_req = hardware.memory_mb;
                chart.storage_type_req = hardware.storage_type;
                chart.touchscreen_req = hardware.touchscreen;
                chart.usb_c_req = hardware.usb_c;
                chart.processor_core_count_req = hardware.processor_core_count;
                chart.processor_frequency_mhz_req = hardware.processor_frequency_mhz;
                chart.storage_capacity_mb_req = hardware.storage_capacity_mb / 1000;
                chart.pen_req = hardware.pen;

                var hardware_rec = _context.Hardware.Where(n => n.Job_ID == Job_ID && n.specs_type == "REC").FirstOrDefault();

                chart.display_size_inch_rec = display_size;
                chart.memory_mb_rec = hardware_rec.memory_mb;
                chart.storage_type_rec = hardware_rec.storage_type;
                chart.touchscreen_rec = hardware_rec.touchscreen;
                chart.usb_c_rec = hardware_rec.usb_c;
                chart.processor_core_count_rec = hardware_rec.processor_core_count;
                chart.processor_frequency_mhz_rec = hardware_rec.processor_frequency_mhz;
                chart.storage_capacity_mb_rec = hardware_rec.storage_capacity_mb / 1000;
                chart.pen_rec = hardware_rec.pen;

                chart.display_size_inch_user = hardware_rec.display_size_inch;
                chart.memory_mb_user = memory_mb;
                chart.storage_type_user = storage_type;
                chart.touchscreen_user = touchscreen;
                chart.usb_c_user = usb_c;
                chart.processor_core_count_user = processor_core;
                chart.processor_frequency_mhz_user = processor_mhz;
                chart.storage_capacity_mb_user = storage_mb / 1000;
                chart.pen_user = pen;

                return View(chart);
            } else
            {
                return RedirectToAction("Index");
            }
        }
    }
}
