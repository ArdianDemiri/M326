﻿using System;
using Microsoft.EntityFrameworkCore;

namespace M326_Project.Data
{
    public class MyDbContext : DbContext
    {
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) 
        {

        }

        public DbSet<Person> Person { get; set; }
        public DbSet<Account> Account { get; set; }
        public DbSet<Job> Job { get; set; }
        public DbSet<Hardware> Hardware { get; set; }
    }
}