﻿using System;
namespace M326_Project.Data
{
    public class Job
    {
        public int ID { get; set; }
        public string JobName { get; set; }
    }
}
