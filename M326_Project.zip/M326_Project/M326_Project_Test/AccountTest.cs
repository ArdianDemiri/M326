﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using M326_Project.Data;

namespace M326_Project_Test
{
    [TestClass]
    public class AccountTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            string password = "ardian123";
            string expected_out = "397ffc303f01d371d1d77dae9b28eb63ef61a6ed75696b1ec4cd1a55a29a5044";

            Account account = new Account();

            // Act
            string actual_out = account.ToSHA256(password);

            // Assert
            Assert.AreEqual(expected_out, actual_out);
        }

        [TestMethod]
        public void TestMethod2()
        {
            Assert.IsFalse(true);
        }
    }
}
